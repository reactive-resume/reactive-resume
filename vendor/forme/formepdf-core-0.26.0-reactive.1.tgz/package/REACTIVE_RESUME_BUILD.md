# Reactive Resume PDF engine build

JavaScript and TypeScript wrapper files remain from published @formepdf/core 0.26.0.
Generated Node, web, and bundler WASM bindings use Forme engine commit
86f0d67781c6265e3796995a7755ddc62b980d67 (v0.26.0), plus Reactive Resume Unicode mapping fixes.
The engine source patch and build recipe live with the vendored artifact.

Changes preserve source text in Unicode CMaps, distinct CIDs for contextual glyph mappings,
and supplementary-plane font coverage. Non-text cluster glyphs keep their shaped outlines;
combining and RTL source suffixes use invisible font text so independent extraction stays intact.
Fallback measurement and positioning use the same font segments; shaping controls stay with
the base font. RTL lines with leading marks use standard Form XObjects to isolate text context.
